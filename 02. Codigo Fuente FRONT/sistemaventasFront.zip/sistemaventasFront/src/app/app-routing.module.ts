import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListarUsuarioComponent } from './componentes/usuario/listar-usuario/listar-usuario.component';
import { ListarEmpleadoComponent } from './componentes/empleado/listar-empleado/listar-empleado.component';
import { ListarClienteComponent } from './componentes/cliente/listar-cliente/listar-cliente.component';
import { ListarProductoComponent } from './componentes/producto/listar-producto/listar-producto.component';
import { AddUsuarioComponent } from './componentes/usuario/add-usuario/add-usuario.component';
import { EditUsuarioComponent } from './componentes/usuario/edit-usuario/edit-usuario.component';
import { AddEmpleadoComponent } from './componentes/empleado/add-empleado/add-empleado.component';
import { EditEmpleadoComponent } from './componentes/empleado/edit-empleado/edit-empleado.component';
import { AddClienteComponent } from './componentes/cliente/add-cliente/add-cliente.component';
import { EditClienteComponent } from './componentes/cliente/edit-cliente/edit-cliente.component';
import { AddProductoComponent } from './componentes/producto/add-producto/add-producto.component';
import { EditProductoComponent } from './componentes/producto/edit-producto/edit-producto.component';
import { CatalogoComponent } from './componentes/venta/catalogo/catalogo.component';
import { CarritoComprasComponent } from './componentes/venta/carrito-compras/carrito-compras.component';
import { LoginComponent } from './componentes/login/login.component';

const routes: Routes = [
  {path: "login", component: LoginComponent },
  {path:'usuarios', component:ListarUsuarioComponent},
  {path:'nuevoUsuario', component:AddUsuarioComponent},
  {path:'editarUsuario', component:EditUsuarioComponent},
  {path:'empleados', component:ListarEmpleadoComponent},
  {path:'nuevoEmpleado', component:AddEmpleadoComponent},
  {path:'editarEmpleado', component:EditEmpleadoComponent},
  {path:'clientes', component:ListarClienteComponent},
  {path:'nuevoCliente', component:AddClienteComponent},
  {path:'editarCliente', component:EditClienteComponent},
  {path:'productos', component:ListarProductoComponent},
  {path:'nuevoProducto', component:AddProductoComponent},
  {path:'editarProducto', component:EditProductoComponent},
  {path:'catalogo', component:CatalogoComponent},
  {path:'carrito', component:CarritoComprasComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
