import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListarUsuarioComponent } from './componentes/usuario/listar-usuario/listar-usuario.component';
import { AddUsuarioComponent } from './componentes/usuario/add-usuario/add-usuario.component';
import { EditUsuarioComponent } from './componentes/usuario/edit-usuario/edit-usuario.component';
import { ListarClienteComponent } from './componentes/cliente/listar-cliente/listar-cliente.component';
import { AddClienteComponent } from './componentes/cliente/add-cliente/add-cliente.component';
import { EditClienteComponent } from './componentes/cliente/edit-cliente/edit-cliente.component';
import { ListarProductoComponent } from './componentes/producto/listar-producto/listar-producto.component';
import { AddProductoComponent } from './componentes/producto/add-producto/add-producto.component';
import { EditProductoComponent } from './componentes/producto/edit-producto/edit-producto.component';
import { ListarEmpleadoComponent } from './componentes/empleado/listar-empleado/listar-empleado.component';
import { AddEmpleadoComponent } from './componentes/empleado/add-empleado/add-empleado.component';
import { EditEmpleadoComponent } from './componentes/empleado/edit-empleado/edit-empleado.component';
import { LoginComponent } from './componentes/login/login.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule} from "@angular/common/http";
import { CatalogoComponent } from './componentes/venta/catalogo/catalogo.component';
import { CarritoComprasComponent } from './componentes/venta/carrito-compras/carrito-compras.component';

@NgModule({
  declarations: [
    AppComponent,
    ListarUsuarioComponent,
    AddUsuarioComponent,
    EditUsuarioComponent,
    ListarClienteComponent,
    AddClienteComponent,
    EditClienteComponent,
    ListarProductoComponent,
    AddProductoComponent,
    EditProductoComponent,
    ListarEmpleadoComponent,
    AddEmpleadoComponent,
    EditEmpleadoComponent,
    LoginComponent,
    CatalogoComponent,
    CarritoComprasComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
