import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cliente } from 'src/app/modelos/Cliente';
import { TipoDocumento } from 'src/app/modelos/TipoDocumento';
import { ClienteService } from 'src/app/servicio/cliente.service';

@Component({
  selector: 'app-add-cliente',
  templateUrl: './add-cliente.component.html',
  styleUrls: ['./add-cliente.component.css']
})
export class AddClienteComponent implements OnInit {

  modelCliente = new Cliente();
  tipoDocumentos!: TipoDocumento[];
  constructor(private router:Router, private clienteService:ClienteService) { }

  ngOnInit(): void {
    this.cargarTipoDocumento();
  }

  guardar(cliente:Cliente) {
    this.clienteService.createCliente(cliente).subscribe(
      data=>{
        this.router.navigate(['clientes']);
        }
      )
    }

    cancelar(){
      this.router.navigate(['clientes']);
    }
  
    cargarTipoDocumento(){
      this.clienteService.getTipoDocumento().subscribe(
        data=>{
          this.tipoDocumentos=data;
          console.log("Los datos son:");
          console.log(data);
        },
        error=>{
          console.log(error);
        }
      );
    }
}
