import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cliente } from 'src/app/modelos/Cliente';
import { TipoDocumento } from 'src/app/modelos/TipoDocumento';
import { ClienteService } from 'src/app/servicio/cliente.service';

@Component({
  selector: 'app-edit-cliente',
  templateUrl: './edit-cliente.component.html',
  styleUrls: ['./edit-cliente.component.css']
})
export class EditClienteComponent implements OnInit {

  cliente: Cliente = new Cliente();
  tipoDocumentos?:TipoDocumento[];

  constructor(private router:Router, private clienteService:ClienteService) { }

  ngOnInit(): void {
    this.editar();
    this.cargarTipoDocumentos();
  }


  editar():void{
    let id= JSON.parse(localStorage.getItem('id') as string);
    this.clienteService.getClienteId(id).subscribe(
      data=>{
         this.cliente=data; 
      }
    )
}

actualizar(cliente:Cliente):void{
  this.clienteService.updateCliente(cliente).subscribe(
    data=>{
      this.cliente=data;
      this.router.navigate(['clientes']);
    }
  );
}

  cancelar(){
    this.router.navigate(['clientes']);
  }

  cargarTipoDocumentos(){
    this.clienteService.getTipoDocumento().subscribe(
      data=>{
        this.tipoDocumentos=data;
        console.log("Los datos son:");
        console.log(data);
      },
      error=>{
        console.log(error);
      }
    );
  }

}
