import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Empleado } from 'src/app/modelos/Empleado';
import { Estado } from 'src/app/modelos/Estado';
import { TipoDocumento } from 'src/app/modelos/TipoDocumento';
import { EmpleadoService } from 'src/app/servicio/empleado.service';

@Component({
  selector: 'app-add-empleado',
  templateUrl: './add-empleado.component.html',
  styleUrls: ['./add-empleado.component.css']
})
export class AddEmpleadoComponent implements OnInit {

  modelEmpleado = new Empleado();
  tipoDocumentos!: TipoDocumento[];
  estados!: Estado[];
  
  constructor(private router:Router, private empleadoService:EmpleadoService) { }

  ngOnInit(): void {
    this.cargarTipoDocumento();
    this.cargarEstado();
  }

  guardar(empleado:Empleado) {
    this.empleadoService.createEmpleado(empleado).subscribe(
      data=>{
        this.router.navigate(['empleados']);
        }
      )
    }

    cancelar(){
      this.router.navigate(['empleados']);
    }
  
    cargarTipoDocumento(){
      this.empleadoService.getTipoDocumento().subscribe(
        data=>{
          this.tipoDocumentos=data;
          console.log("Los datos son:");
          console.log(data);
        },
        error=>{
          console.log(error);
        }
        );
      }

      cargarEstado(){
        this.empleadoService.getEstado().subscribe(
          data=>{
            this.estados=data;
            console.log("Los datos son:");
            console.log(data);
          },
          error=>{
            console.log(error);
          }
          );
        }
  
  

}
