import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Empleado } from 'src/app/modelos/Empleado';
import { Estado } from 'src/app/modelos/Estado';
import { TipoDocumento } from 'src/app/modelos/TipoDocumento';
import { EmpleadoService } from 'src/app/servicio/empleado.service';

@Component({
  selector: 'app-edit-empleado',
  templateUrl: './edit-empleado.component.html',
  styleUrls: ['./edit-empleado.component.css']
})
export class EditEmpleadoComponent implements OnInit {

  empleado: Empleado = new Empleado();
  tipoDocumentos?:TipoDocumento[];
  estados?:Estado[];

  constructor(private router:Router, private empleadoService:EmpleadoService) { }

  ngOnInit(): void {
    this.editar();
    this.cargarTipoDocumentos();
    this.cargarEstados();
  }


  editar(): void {
    let id=JSON.parse(localStorage.getItem('id') as string);
    this.empleadoService.getEmpleadoId(id).subscribe(
      data=>{
        this.empleado=data;
      }
    )
  }

  actualizar(empleado:Empleado): void {
    this.empleadoService.updateEmpleado(this.empleado).subscribe(
      data=>{
        this.empleado=data;
        this.router.navigate(['empleados']);
      }
    )
  }

  cancelar(){
    this.router.navigate(['empleados']);
  }

  cargarTipoDocumentos(){
    this.empleadoService.getTipoDocumento().subscribe(
      data=>{
        this.tipoDocumentos=data;
        console.log("Los datos son:");
        console.log(data);
      },
      error=>{
        console.log(error);
      }
    );
  }

  cargarEstados(){
    this.empleadoService.getEstado().subscribe(
      data=>{
        this.estados=data;
        console.log("Los datos son:");
        console.log(data);
      },
      error=>{
        console.log(error);
      }
    );
  }
}
