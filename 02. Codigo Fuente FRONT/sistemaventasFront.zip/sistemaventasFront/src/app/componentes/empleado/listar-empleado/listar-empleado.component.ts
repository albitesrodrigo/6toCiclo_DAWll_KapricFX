import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Empleado } from 'src/app/modelos/Empleado';
import { Usuario } from 'src/app/modelos/Usuario';
import { EmpleadoService } from 'src/app/servicio/empleado.service';

@Component({
  selector: 'app-listar-empleado',
  templateUrl: './listar-empleado.component.html',
  styleUrls: ['./listar-empleado.component.css']
})
export class ListarEmpleadoComponent implements OnInit {

  empleados?:Empleado[];
  usuario: Usuario[] = [];

  constructor(private router:Router, private empleadoService:EmpleadoService) { }

  ngOnInit(): void {
    this.empleadoService.getEmpleados().subscribe(
      data=>{
        this.empleados=data;
        console.log(data);
      },
      error=>{
        console.log(error);
      }
 );
}

getUsuarioContrasenia(idEmpleado: number): string {
  const usuario = this.usuario.find(tipo => tipo.idUsuario === idEmpleado);
  return usuario ? usuario.contrasenia : 'Desconocido';
}

  nuevo():void {
  this.router.navigate(['nuevoEmpleado']);
  }

  editar(empleado:Empleado):void {
  localStorage.setItem("id",empleado.idEmpleado.toString());
  this.router.navigate(['editarEmpleado']);
  }

  eliminar(empleado:Empleado):void{
  this.empleadoService.deleteEmpleado(empleado).subscribe(data=>{
      this.empleados=this.empleados!.filter(p=>p!==empleado);
    });
  }  
}
