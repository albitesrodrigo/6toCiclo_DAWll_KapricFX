import { Component, OnInit } from '@angular/core';
import { UsuarioService } from 'src/app/servicio/usuario.service';
import { Usuario } from 'src/app/modelos/Usuario';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  usuarios!: Usuario[];

  constructor(public usuarioService: UsuarioService) { }

  ngOnInit(): void {
  }

  /*login() {
    const usuario: Usuario = { password: this.password };
    this.usuarioService.login(usuario).subscribe(
      (data) => {
        console.log(data);
        // Aquí podrías manejar la respuesta del servidor, como redireccionar al usuario o mostrar mensajes
      },
      (error) => {
        console.error('Ocurrió un error en el inicio de sesión:', error);
        // Aquí puedes manejar el error, como mostrar un mensaje de error al usuario
      }
    );
  }*/
}

