import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Categoria } from 'src/app/modelos/Categoria';
import { Producto } from 'src/app/modelos/Producto';
import { ProductoService } from 'src/app/servicio/producto.service';

@Component({
  selector: 'app-add-producto',
  templateUrl: './add-producto.component.html',
  styleUrls: ['./add-producto.component.css']
})
export class AddProductoComponent implements OnInit {

  modelProducto = new Producto();
  categorias!: Categoria[];

  constructor(private router:Router, private productoService:ProductoService) { }

  ngOnInit(): void {
    this.cargarCategoria();
  }

  guardar(producto:Producto) {
    this.productoService.createProducto(producto).subscribe(
      data=>{
        this.router.navigate(['productos']);
      }
    )
  }

  cancelar(){
    this.router.navigate(['productos']);
  }

  cargarCategoria(){
    this.productoService.getCategorias().subscribe(
      data=>{
        this.categorias=data;
        console.log("Los datos son:");
        console.log(data);
      },
      error=>{
        console.log(error);
      }
      );
    }

  }
