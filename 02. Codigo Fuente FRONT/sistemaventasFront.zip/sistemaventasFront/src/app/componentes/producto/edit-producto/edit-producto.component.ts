import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Categoria } from 'src/app/modelos/Categoria';
import { Producto } from 'src/app/modelos/Producto';
import { ProductoService } from 'src/app/servicio/producto.service';

@Component({
  selector: 'app-edit-producto',
  templateUrl: './edit-producto.component.html',
  styleUrls: ['./edit-producto.component.css']
})
export class EditProductoComponent implements OnInit {

  producto: Producto = new Producto();
  categorias!: Categoria[];

  constructor(private router:Router, private productoService:ProductoService) { }

  ngOnInit(): void {
    this.editar();
    this.cargarCategorias();
  }

  editar(): void {
    let idProducto=JSON.parse(localStorage.getItem('idProducto') as string);
    this.productoService.getProductoId(idProducto).subscribe(
      data=>{
        this.producto=data;
      }
    )
  }

  actualizar(producto:Producto): void {
    this.productoService.updateProducto(producto).subscribe(
      data=>{
        this.producto=data;
        this.router.navigate(['productos']);
      }
    )
  }

  cancelar(){
    this.router.navigate(['productos']);
  }

  cargarCategorias(){
    this.productoService.getCategorias().subscribe(
      data=>{
        this.categorias=data;
        console.log("Los datos son:");
        console.log(data);
      },
      error=>{
        console.log(error);
      }
    );
  }

}
