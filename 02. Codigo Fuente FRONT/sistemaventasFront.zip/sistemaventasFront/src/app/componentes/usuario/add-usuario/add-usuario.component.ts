import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Empleado } from 'src/app/modelos/Empleado';
import { Rol } from 'src/app/modelos/Rol';
import { Usuario } from 'src/app/modelos/Usuario';
import { UsuarioService } from 'src/app/servicio/usuario.service';

@Component({
  selector: 'app-add-usuario',
  templateUrl: './add-usuario.component.html',
  styleUrls: ['./add-usuario.component.css']
})
export class AddUsuarioComponent implements OnInit {

  modelUsuario = new Usuario();
  empleados!:Empleado[];
  roles!:Rol[];

  constructor(private router:Router, private usuarioService:UsuarioService) { }

  ngOnInit(): void {
    this.cargarEmpleado();
    this.cargarRol();
  }

  guardar(usuario:Usuario) {
    this.usuarioService.createUsuario(usuario).subscribe(
      data=>{
        this.router.navigate(['usuarios']);
        }
      )
    }
    cancelar(){
      this.router.navigate(['usuarios']);
    }

    cargarEmpleado(){
      this.usuarioService.getEmpleado().subscribe(
        data=>{
          this.empleados=data;
          console.log("Los datos son:");
          console.log(data);
        },
        error=>{
          console.log(error);
        }
      );
    }
  
    cargarRol(){
      this.usuarioService.getRol().subscribe(
        data=>{
          this.roles=data;
          console.log("Los datos son:");
          console.log(data);
        },
        error=>{
          console.log(error);
        }
      );
    }
  
  }