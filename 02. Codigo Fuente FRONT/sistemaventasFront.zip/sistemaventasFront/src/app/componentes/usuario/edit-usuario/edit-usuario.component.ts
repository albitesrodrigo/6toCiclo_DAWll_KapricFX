import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Empleado } from 'src/app/modelos/Empleado';
import { Rol } from 'src/app/modelos/Rol';
import { Usuario } from 'src/app/modelos/Usuario';
import { UsuarioService } from 'src/app/servicio/usuario.service';

@Component({
  selector: 'app-edit-usuario',
  templateUrl: './edit-usuario.component.html',
  styleUrls: ['./edit-usuario.component.css']
})
export class EditUsuarioComponent implements OnInit {

  usuario: Usuario = new Usuario();
  empleados?:Empleado[];
  roles?:Rol[];

  constructor(private router:Router, private usuarioService:UsuarioService) { }

  ngOnInit(): void {
    this.editar();
    this.cargarEmpleados();
    this.cargarRoles();
  }

  editar():void{
    let idUsuario= JSON.parse(localStorage.getItem('idUsuario') as string);
    this.usuarioService.getUsuarioId(idUsuario).subscribe(
      data=>{
         this.usuario=data; 
      }
    )
}

actualizar(usuario:Usuario):void{
  this.usuarioService.updateUsuario(usuario).subscribe(
    data=>{
        this.usuario=data;
        this.router.navigate(['usuarios']);
    }
  );
}

  cancelar(){
    this.router.navigate(['usuarios']);
  }

  cargarEmpleados(){
    this.usuarioService.getEmpleado().subscribe(
      data=>{
        this.empleados=data;
        console.log("Los datos son:");
        console.log(data);
      },
      error=>{
        console.log(error);
      }
    );
  }

  cargarRoles(){
    this.usuarioService.getRol().subscribe(
      data=>{
        this.roles=data;
        console.log("Los datos son:");
        console.log(data);
      },
      error=>{
        console.log(error);
      }
    );
  }


}
