import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario } from 'src/app/modelos/Usuario';
import { UsuarioService } from 'src/app/servicio/usuario.service';

@Component({
  selector: 'app-listar-usuario',
  templateUrl: './listar-usuario.component.html',
  styleUrls: ['./listar-usuario.component.css']
})
export class ListarUsuarioComponent implements OnInit {

  usuarios?:Usuario[];

  constructor(private usuarioService:UsuarioService, private router:Router) { }

  ngOnInit(): void {

    this.usuarioService.getUsuarios().subscribe(
         data=>{
           this.usuarios=data;
           console.log(data);
         },
         error=>{
           console.log(error);
         }
    );
 }

 nuevo():void {
   this.router.navigate(['nuevoUsuario']);
 }

 editar(usuario:Usuario):void {
   localStorage.setItem("idUsuario",usuario.idUsuario.toString());
   this.router.navigate(['editarUsuario']);
 }

 eliminar(usuario:Usuario):void{
   this.usuarioService.deleteUsuario(usuario).subscribe(data=>{
       this.usuarios=this.usuarios!.filter(p=>p!==usuario);
     });
 }   
}
