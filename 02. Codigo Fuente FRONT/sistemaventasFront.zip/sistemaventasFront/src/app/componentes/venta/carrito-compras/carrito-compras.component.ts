import { Component, OnInit } from '@angular/core';
import { Venta } from 'src/app/modelos/Venta';
import { VentaDetalle } from 'src/app/modelos/VentaDetalle';
import { CatalogoCarrito } from '../catalogoCarrito';
import { CarritoService } from 'src/app/servicio/carrito.service';
import { Router } from '@angular/router';
import { Producto } from 'src/app/modelos/Producto';
import { Cliente } from 'src/app/modelos/Cliente';
import { Empleado } from 'src/app/modelos/Empleado';

@Component({
  selector: 'app-carrito-compras',
  templateUrl: './carrito-compras.component.html',
  styleUrls: ['./carrito-compras.component.css']
})
export class CarritoComprasComponent implements OnInit {

  venta:Venta = new Venta();
  carrito: VentaDetalle[] = [];
  total:number=0;

  constructor(private catalogo:CatalogoCarrito, private carritoService:CarritoService, private router:Router ) {
    this.carrito = this.catalogo.obtenerItems();
    this.total = this.catalogo.calcularTotal();
   }
  
  ngOnInit(): void {
  }

  calcularTotal(): number {
    return this.carrito.reduce((total, detalle) => total + detalle.importe, 0);
  }

  eliminarItemCarrito(producto:Producto){
    const index=this.carrito.findIndex(value => value.idDetalleVenta===producto.idProducto);
    if(index>-1){
      this.carrito.splice(index,1);
    }

    this.total=this.calcularTotal();
    this.carrito = this.catalogo.obtenerItems();
  }

  actualizarCantidad(idProducto: number, nuevaCantidad: number): void {
    const detalle = this.carrito.find(item => item.producto.idProducto === idProducto);
    if (detalle) {
      detalle.cantidad = nuevaCantidad;
      detalle.importe = detalle.preVenta * nuevaCantidad;
      this.total=this.calcularTotal();
    }
  }

  registrarCompra(){
    //Simulamos al cliente 1
    this.venta.cliente = new Cliente();  
    this.venta.cliente.idCliente = 1; 
    this.venta.empleado = new Empleado();  
    this.venta.empleado.idEmpleado = 1; 

    //Obtener fecha actual y formatearla
    const fechaActual = new Date();
    const fechaFormateada = fechaActual.toISOString().slice(0, 10); // Formato "yyyy-MM-dd"

    //Completamos el pedido con la fecha y el pedidoDetalle 
    this.venta.fechaVenta=fechaFormateada;
    this.venta.ventaDetalle=this.carrito;
      
    this.carritoService.createVenta(this.venta).subscribe(
      data=>{
         console.log('OK registro');
         //Limpiamos carrito y regresamos al catálogo
         this.carrito=[];
         this.catalogo.limpiarItems();
         this.router.navigate(['catalogo']);
      }
    )
  }
}
