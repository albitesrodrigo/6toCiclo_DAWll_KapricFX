import { Component, OnInit } from '@angular/core';
import { Producto } from 'src/app/modelos/Producto';
import { CatalogoCarrito } from '../catalogoCarrito';
import { ProductoService } from 'src/app/servicio/producto.service';
import { VentaDetalle } from 'src/app/modelos/VentaDetalle';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent implements OnInit {

  productos?:Producto[];

  constructor(private catalogoCarrito: CatalogoCarrito, private productoService:ProductoService) { }

  ngOnInit(): void {
    this.obtenerProductos();
  }

  obtenerProductos():void {
    this.productoService.getProductos().subscribe(
      data=>{
        this.productos=data;
        console.log(data);
      },
      error=>{
        console.log(error);
      }
    );
  }

  agregarAlCarrito(producto: Producto):void{
    
    const ventaDetalleExistente = this.catalogoCarrito.items.find(detalle => detalle.producto.idProducto === producto.idProducto); 

    if (ventaDetalleExistente) {
      ventaDetalleExistente.cantidad += 1;
      ventaDetalleExistente.importe = ventaDetalleExistente.cantidad * producto.precio;
    } else {
      
      const ventaDetalle: VentaDetalle = {
        idDetalleVenta: producto.idProducto,
        producto: producto,  
        cantidad: 1,
        preVenta: producto.precio,
        importe: producto.precio 
      };
  
      this.catalogoCarrito.items.push(ventaDetalle);
    }

  }
}
