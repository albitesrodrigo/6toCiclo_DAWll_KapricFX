import { Injectable } from '@angular/core';
import { VentaDetalle } from 'src/app/modelos/VentaDetalle';

@Injectable({
  providedIn: 'root'
})
export class CatalogoCarrito {

  constructor() { }

  public items: VentaDetalle[] = [];
 
  obtenerItems(): VentaDetalle[] {
    return this.items;
  }

   
  limpiarItems():void{
    this.items=[];
  }

  calcularTotal(): number {
    return this.items.reduce((total, item) => total + item.importe, 0);
  }
}