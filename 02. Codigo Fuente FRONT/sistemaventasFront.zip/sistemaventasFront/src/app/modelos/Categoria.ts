export class Categoria {
    idCategoria: number;
    desCategoria: string;

    constructor() {
        this.idCategoria = 0;
        this.desCategoria = "";
    }
}