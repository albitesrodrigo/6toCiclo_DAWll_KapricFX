import { TipoDocumento } from "./TipoDocumento";

export class Cliente {
    idCliente: number;
    nombre: string;
    apePaterno: string;
    apeMaterno: string;
    numDocumento: string;
    direccion: string;
    correo: string;
    tipoDocumento!: TipoDocumento;

    constructor(
    ){
        this.idCliente=0;
        this.nombre="";
        this.apePaterno="";
        this.apeMaterno="";
        this.numDocumento="";
        this.direccion="";
        this.correo="";
    }
}