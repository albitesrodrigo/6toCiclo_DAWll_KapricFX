import { Estado } from "./Estado";
import { TipoDocumento } from "./TipoDocumento";

export class Empleado {
    idEmpleado: number;
    nombre: string;
    apePaterno: string
    apeMaterno:string;
    numDocumento: string;
    direccion:string;
    telefono: number;
    correo:string;
    fechaNacimiento:string;
    tipoDocumento!: TipoDocumento;
    estado!: Estado;

    constructor(
    ){
        this.idEmpleado=0;
        this.nombre="";
        this.telefono=0;
        this.apePaterno="";
        this.apeMaterno="";
        this.numDocumento="";
        this.direccion="";
        this.telefono=0;
        this.correo="";
        this.fechaNacimiento="";
    }
}