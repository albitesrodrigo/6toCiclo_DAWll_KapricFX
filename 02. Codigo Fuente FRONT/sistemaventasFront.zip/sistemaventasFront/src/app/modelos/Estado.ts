export class Estado {
    idEstado: number;
    desEstado: string;

    constructor() {
        this.idEstado = 0;
        this.desEstado = "";
    }
}