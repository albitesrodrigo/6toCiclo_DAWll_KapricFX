import { Categoria } from "./Categoria";
import { Estado } from "./Estado";

export class Producto {
    idProducto: number;
    nomProducto: string;
    stock: number;
    precio: number;
    categoria!: Categoria;

    constructor(){
        this.idProducto=0;
        this.nomProducto="";
        this.stock=0;
        this.precio=0;
    }
}