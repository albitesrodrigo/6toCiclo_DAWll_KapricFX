export class Rol {
    idRol: number;
    desRol: string;

    constructor() {
        this.idRol = 0;
        this.desRol = "";
    }
}