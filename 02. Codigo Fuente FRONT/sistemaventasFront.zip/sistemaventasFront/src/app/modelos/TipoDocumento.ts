export class TipoDocumento {
    idTipo: number;
    desTipo: string;

    constructor() {
        this.idTipo = 0;
        this.desTipo = "";
    }
}