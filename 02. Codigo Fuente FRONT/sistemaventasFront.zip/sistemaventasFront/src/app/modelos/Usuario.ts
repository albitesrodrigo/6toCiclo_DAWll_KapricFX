import { Empleado } from "./Empleado";
import { Rol } from "./Rol";

export class Usuario {
    idUsuario: number;
    userName: string;
    contrasenia: string;
    empleado!: Empleado;
    rol!: Rol;

    constructor(){
        this.idUsuario=0;
        this.userName="";
        this.contrasenia="";
    }
}