import { Cliente } from "./Cliente";
import { VentaDetalle } from "./VentaDetalle";
import { Empleado } from "./Empleado";

export class Venta {
    idVenta: number;
    fechaVenta: string;
    cliente!: Cliente;
    empleado!: Empleado;
    ventaDetalle!: VentaDetalle[];

    constructor(){
        this.idVenta=0;
        this.fechaVenta="";
    }
}