import { Producto } from "./Producto";

export class VentaDetalle {
    idDetalleVenta: number;
    producto!: Producto;
    cantidad: number;
    preVenta: number;
    importe: number;

    constructor(){
        this.idDetalleVenta=0;
        this.cantidad=0;
        this.preVenta=0;
        this.importe=0;
    }
}