import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Venta } from '../modelos/Venta';
import { Cliente } from '../modelos/Cliente';
import { Empleado } from '../modelos/Empleado';

@Injectable({
  providedIn: 'root'
})
export class CarritoService {

  constructor(private http:HttpClient) { }
  urlPro = 'http://localhost:8080/api/productos';
  urlVen = 'http://localhost:8080/api/ventas';
  urlCli = 'http://localhost:8080/api/clientes';
  urlEmp = 'http://localhost:8080/api/empleados';

  createVenta(venta:Venta) {
    return this.http.post<Venta>(this.urlVen,venta);
  }
  
  getCliente(){
    return this.http.get<Cliente[]>(this.urlCli);
  }

  getEmpleado(){
    return this.http.get<Empleado[]>(this.urlEmp);
  }

}
