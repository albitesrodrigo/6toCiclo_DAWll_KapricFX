import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Cliente } from '../modelos/Cliente';
import { TipoDocumento } from '../modelos/TipoDocumento';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {

  constructor(private http:HttpClient) { }
  url = 'http://localhost:8080/api/clientes';
  urlTip = 'http://localhost:8080/api/tipodocumentos';

  getClientes(){
    return this.http.get<Cliente[]>(this.url);
  }

  createCliente(cliente:Cliente) {
    return this.http.post<Cliente>(this.url,cliente);
  }

  getClienteId(idCliente:number) {
    return this.http.get<Cliente>(this.url+"/"+idCliente);
  }

  updateCliente(cliente: Cliente) {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put<Cliente>(this.url + "/" + cliente.idCliente, cliente, { headers });
  }

  deleteCliente(cliente:Cliente) {
    return this.http.delete<Cliente>(this.url+"/"+cliente.idCliente);
  }

  getTipoDocumento(){
    return this.http.get<TipoDocumento[]>(this.urlTip);
  }
}
