import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Empleado } from '../modelos/Empleado';
import { TipoDocumento } from '../modelos/TipoDocumento';
import { Estado } from '../modelos/Estado';
import { Rol } from '../modelos/Rol';

@Injectable({
  providedIn: 'root'
})
export class EmpleadoService {

  constructor(private http:HttpClient) { }
  url = 'http://localhost:8080/api/empleados';
  urlTip = 'http://localhost:8080/api/tipodocumentos';
  urlEst = 'http://localhost:8080/api/estados';

  getEmpleados(){
    return this.http.get<Empleado[]>(this.url);
  }

  createEmpleado(empleado:Empleado) {
    return this.http.post<Empleado>(this.url,empleado);
  }

  getEmpleadoId(idEmpleado:number) {
    return this.http.get<Empleado>(this.url+"/"+idEmpleado);
  }

  updateEmpleado(empleado:Empleado) {
    return this.http.put<Empleado>(this.url,empleado);
  }

  deleteEmpleado(empleado:Empleado) {
    return this.http.delete<Empleado>(this.url+"/"+empleado.idEmpleado);
  }

  getTipoDocumento(){
    return this.http.get<TipoDocumento[]>(this.urlTip);
  }

  getEstado(){
    return this.http.get<Estado[]>(this.urlEst);
  }

}
