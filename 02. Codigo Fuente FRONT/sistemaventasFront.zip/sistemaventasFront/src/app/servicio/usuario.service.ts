import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Usuario } from '../modelos/Usuario';
import { Observable } from 'rxjs/internal/Observable';
import { Rol } from '../modelos/Rol';
import { Empleado } from '../modelos/Empleado';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  constructor(private http:HttpClient) { }
  url = 'http://localhost:8080/api/usuarios';
  urlEmp = 'http://localhost:8080/api/empleados';
  urlRol = 'http://localhost:8080/api/roles';

  login(usuario: Usuario): Observable<any> {
    return this.http.post(this.url, usuario);
  }
  
  getUsuarios(){
    return this.http.get<Usuario[]>(this.url);
  }

  createUsuario(usuario:Usuario) {
    return this.http.post<Usuario>(this.url,usuario);
  }

  getUsuarioId(idUsuario:number) {
    return this.http.get<Usuario>(this.url+"/"+idUsuario);
  }

  updateUsuario(usuario:Usuario) {
    return this.http.put<Usuario>(this.url,usuario);
  }

  deleteUsuario(usuario:Usuario) {
    return this.http.delete<Usuario>(this.url+"/"+usuario.idUsuario);
  }

  getEmpleado(){
    return this.http.get<Empleado[]>(this.urlEmp);
  }

  getRol(){
    return this.http.get<Rol[]>(this.urlRol);
  }
}
